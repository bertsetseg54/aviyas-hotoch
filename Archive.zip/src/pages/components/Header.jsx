import Link from "next/link";

export default function Header() {
  return (
    <div className=" max-w-[90%] m-auto">
      <div className="flex justify-center items-center p-3 font-semibold">
        <Link href="/" className="flex h-[80px] px-[10px]">
          <img
            src="https://scontent-nrt1-1.xx.fbcdn.net/v/t1.6435-9/54729292_415659388992065_5417537954648162304_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=RXEFEC-9EAkQ7kNvwGFlsE6&_nc_oc=AdlnB6PAjXyomd_-gOJNThDyNrQVI7Q5iMt5ahkOIjiptjjc6d3waXR9AdVJATJLC1cXSmZGCirRz6KAHbUo0nm6&_nc_zt=23&_nc_ht=scontent-nrt1-1.xx&_nc_gid=P49JnvqN5VqHvk4kNX3dGw&oh=00_AfFBsRh0_ygAZiI7bcUf-VCedh4qXG6KG2FvH64x9sLvAg&oe=683A5ED1"
            alt=""
          />
        </Link>
        <p className="text-3xl text-center">
          Хөвсгөл аймгийн Мөрөн сумын ерөнхий боловсролын "АВЬЯАС" сургуулийн
          хөтөч
        </p>
      </div>
    </div>
  );
}
