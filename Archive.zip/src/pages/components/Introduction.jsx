export default function Introduction() {
  return (
    <div className="bg-[black]">
      <div className="w-[70%] flex justify-center flex-wrap gap-3 px-5 bg-[black] mb-[200px] pb-[25px]">
        {/* <img src="./huwaari.png" className="h-[70vh]" alt="" /> */}
        <div className="w-[10%]">
          <button className="flex flex-col relative rounded-md w-full mt-[30%] pt-[95%] pb-[10%] bg-[#FFFFFF] text-xl h-[225px]">
            <img src="./teacherphoto.png" alt="" className="imgtag" />
            <p className="text-[#283747] font-semibold text-lg">
              Д.Нарансайхан
            </p>
            <p className="text-[#5d6d7e]   text-base font-light">
              Нийгэм, Түүх, Уран зохиол
            </p>
          </button>
        </div>
      </div>
    </div>
  );
}
