export default function Landingpage() {
  return <div>momo</div>;
}
