export default function Litag() {
  return (
    <div>
      <ul
        tabIndex={0}
        className="dropdown-content menu bg-base-100 rounded-box z-1 w-52 p-2 shadow-sm flex flex-col"
      >
        <li>
          <button className="">1А</button>
        </li>
        <li>
          <button className="">1Б</button>
        </li>
        <li>1В</li>
        <li>2А</li>
        <li>2Б</li>
        <li>2В</li>
        <li>3А</li>
        <li>3Б</li>
        <li>4А</li>
        <li>4Б</li>
        <li>5А</li>
        <li>5Б</li>
        <li>6А</li>
        <li>6Б</li>
        <li>6В</li>
        <li>7А</li>
        <li>7Б</li>
        <li>8А</li>
        <li>8Б</li>
        <li>9А</li>
        <li>9Б</li>
        <li>10А</li>
        <li>10Б</li>
        <li>10В</li>
        <li>11А</li>
        <li>11Б</li>
        <li>12А</li>
        <li>12Б</li>
      </ul>
    </div>
  );
}
