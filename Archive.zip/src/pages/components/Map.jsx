export default function Map() {
  return <div>kkk</div>;
}
