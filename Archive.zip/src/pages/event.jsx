import Event from "./components/Event";

export default function Home() {
  return (
    <div>
      <Event />
    </div>
  );
}
