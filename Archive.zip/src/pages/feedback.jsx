import Feedback from "./components/Feedback";

export default function Home() {
  return (
    <div>
      <Feedback />
    </div>
  );
}
