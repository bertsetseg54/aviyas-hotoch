import Landingpage from "./components/Landingpage";

export default function Home() {
  return (
    <div>
      <Landingpage />
    </div>
  );
}
