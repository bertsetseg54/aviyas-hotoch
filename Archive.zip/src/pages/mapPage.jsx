import Map from "./components/Map";

export default function Home() {
  return (
    <div>
      <Map />
    </div>
  );
}
