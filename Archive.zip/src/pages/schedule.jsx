import Header from "./components/Header";
import Nav from "./components/Nav";
import Schedule from "./components/Schedule";

export default function Home() {
  return (
    <div>
      <Schedule />
    </div>
  );
}
